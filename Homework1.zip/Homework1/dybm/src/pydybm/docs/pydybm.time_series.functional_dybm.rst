pydybm\.time\_series\.functional\_dybm module
=============================================

.. automodule:: pydybm.time_series.functional_dybm
    :members:
    :undoc-members:
    :show-inheritance:
