pydybm\.arraymath\.dycupy\.magma module
=======================================

.. automodule:: pydybm.arraymath.dycupy.magma
    :members:
    :undoc-members:
    :show-inheritance:
