pydybm\.time\_series\.batch\_dybm module
========================================

.. automodule:: pydybm.time_series.batch_dybm
    :members:
    :undoc-members:
    :show-inheritance:
