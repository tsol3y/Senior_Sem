pydybm\.time\_series\.rnn\_gaussian\_dybm module
================================================

.. automodule:: pydybm.time_series.rnn_gaussian_dybm
    :members:
    :undoc-members:
    :show-inheritance:
