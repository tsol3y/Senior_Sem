pydybm\.time\_series\.batch\_gaussian\_dybm module
==================================================

.. automodule:: pydybm.time_series.batch_gaussian_dybm
    :members:
    :undoc-members:
    :show-inheritance:
